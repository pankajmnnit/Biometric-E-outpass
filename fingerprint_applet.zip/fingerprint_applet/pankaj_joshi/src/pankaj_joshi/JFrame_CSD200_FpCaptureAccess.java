/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pankaj_joshi;

/*
 * Decompiled with CFR 0_118.
 * 
 * Could not load the following classes:
 *  mmm.cogent.fpCaptureApi.CapturedImageData
 *  mmm.cogent.fpCaptureApi.DeviceInfo
 *  mmm.cogent.fpCaptureApi.IFingerprintCaptureAPI
 *  mmm.cogent.fpCaptureApi.IFingerprintCaptureCallbackAPI
 *  mmm.cogent.fpCaptureApi.MMMCogentCSD200DeviceImpl
 */
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.LayoutManager;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.awt.image.DataBuffer;
import java.awt.image.DataBufferByte;
import java.awt.image.WritableRaster;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.URL;
import java.util.Calendar;
import java.util.Random;
import javax.imageio.ImageIO;
import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;
import mmm.cogent.fpCaptureApi.CapturedImageData;
import mmm.cogent.fpCaptureApi.DeviceInfo;
import mmm.cogent.fpCaptureApi.IFingerprintCaptureAPI;
import mmm.cogent.fpCaptureApi.IFingerprintCaptureCallbackAPI;
import mmm.cogent.fpCaptureApi.MMMCogentCSD200DeviceImpl;

public class JFrame_CSD200_FpCaptureAccess
extends JFrame {
    private static final long serialVersionUID = 1;
    IFingerprintCaptureAPI fingerprintCaptureApi;
    int currentSessionId = -1;
    byte[] previousFMR = null;
    private JPanel contentPane;
    private JLabel lblCaptureImg;
    private JButton btnInitialize;
    private JButton btnCapture;
    private JButton btnAbort;
    private JButton btnForceCapture;
    private JButton btnDeviceInfo;
    private JButton btnDeinit;
    private JButton btnSaveBmpImage;
    private JButton btnSaveRawImage;
    private JButton btnMatchFingerprints;
    private JLabel lblFpImg1;
    private JLabel lblFpImg2;
    private JLabel lblLogo;
    private JRadioButton rbFp1;
    private JRadioButton rbFp2;
    private JLabel lblmCogentCsd;
    private JTextArea textArea;
    private JDialog dialog;
    private Image fpImageToDisplay;
    private byte[] displayedImageByteArray;
    boolean captureFinished = false;
    boolean calibrating = false;
    boolean conScanner = true;
    byte[] fp1BMPBytes;
    byte[] fp1FMRBytes;
    byte[] fp2BMPBytes;
    byte[] fp2FMRBytes;
    private JLabel lblNfiq2;
    private JLabel lblNfiq1;

    private void updateTextArea(final String text) {
        SwingUtilities.invokeLater(new Runnable(){

            public void run() {
                JFrame_CSD200_FpCaptureAccess.this.textArea.setText(String.valueOf(JFrame_CSD200_FpCaptureAccess.this.textArea.getText()) + text);
            }
        });
    }

    public byte[] getDisplayedImageByteArray() {
        return this.displayedImageByteArray;
    }

    public void setDisplayedImageByteArray(byte[] displayedImageByteArray) {
        if (displayedImageByteArray == null) {
            this.setFpImageToDisplay(null);
        } else {
            BufferedImage capturedImage = null;
            try {
                capturedImage = ImageIO.read(new ByteArrayInputStream(displayedImageByteArray));
            }
            catch (IOException var3_3) {
                // empty catch block
            }
            this.setFpImageToDisplay(capturedImage);
        }
        this.displayedImageByteArray = displayedImageByteArray;
    }

    public Image getFpImageToDisplay() {
        if (this.fpImageToDisplay == null) {
            return new ImageIcon(JFrame_CSD200_FpCaptureAccess.class.getResource("/img/Blank.JPG")).getImage();
        }
        return this.fpImageToDisplay;
    }

    public void setFpImageToDisplay(Image fpImageToDisplay) {
        this.fpImageToDisplay = fpImageToDisplay;
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable(){

            public void run() {
                try {
                    JFrame_CSD200_FpCaptureAccess frame = new JFrame_CSD200_FpCaptureAccess();
                    frame.setVisible(true);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public JFrame_CSD200_FpCaptureAccess() {
        this.setResizable(false);
        this.init();
    }

    public void init() {
        OutputStream out = new OutputStream(){

            public void write(int b) throws IOException {
                JFrame_CSD200_FpCaptureAccess.this.updateTextArea(String.valueOf((char)b));
            }

            public void write(byte[] b, int off, int len) throws IOException {
                JFrame_CSD200_FpCaptureAccess.this.updateTextArea(new String(b, off, len));
            }

            public void write(byte[] b) throws IOException {
                this.write(b, 0, b.length);
            }
        };
        System.setOut(new PrintStream(out, true));
        System.setErr(new PrintStream(out, true));
        this.setIconImage(Toolkit.getDefaultToolkit().getImage(JFrame_CSD200_FpCaptureAccess.class.getResource("/img/3M_Logo.gif")));
        this.dialog = null;
        this.fingerprintCaptureApi = new MMMCogentCSD200DeviceImpl();
        this.fingerprintCaptureApi.initDevice();
        this.fp1BMPBytes = null;
        this.fp1BMPBytes = null;
        this.fp1FMRBytes = null;
        this.fp2FMRBytes = null;
        this.setDefaultCloseOperation(3);
        this.setBounds(100, 100, 765, 622);
        this.contentPane = new JPanel();
        this.contentPane.setBackground(Color.WHITE);
        this.contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        this.setContentPane(this.contentPane);
        this.contentPane.setLayout(null);
        this.lblCaptureImg = new JLabel("");
        this.lblCaptureImg.setBounds(68, 120, 114, 172);
        this.lblCaptureImg.setBorder(new LineBorder(Color.black));
        this.contentPane.add(this.lblCaptureImg);
        this.btnInitialize = new JButton("Initialize");
        this.btnInitialize.setBounds(28, 315, 105, 23);
        this.btnInitialize.addActionListener(new ActionListener(){

            public void actionPerformed(ActionEvent arg0) {
                JFrame_CSD200_FpCaptureAccess.this.setDisplayedImageByteArray(null);
                JFrame_CSD200_FpCaptureAccess.this.repaint();
                Thread initThread = new Thread(new initWorker());
                initThread.setDaemon(true);
                initThread.start();
            }
        });
        this.btnInitialize.setFont(new Font("Tahoma", 0, 11));
        this.contentPane.add(this.btnInitialize);
        this.btnCapture = new JButton("Capture");
        this.btnCapture.setBounds(28, 349, 105, 23);
        this.btnCapture.addActionListener(new ActionListener(){

            public void actionPerformed(ActionEvent arg0) {
                JFrame_CSD200_FpCaptureAccess.this.setDisplayedImageByteArray(null);
                JFrame_CSD200_FpCaptureAccess.this.repaint();
                System.out.println("isDeviceConnected: " + JFrame_CSD200_FpCaptureAccess.this.fingerprintCaptureApi.isDeviceConnected());
                System.out.println("isDeviceInitialized: " + JFrame_CSD200_FpCaptureAccess.this.fingerprintCaptureApi.isDeviceInitialized());
                if (JFrame_CSD200_FpCaptureAccess.this.fingerprintCaptureApi.isDeviceConnected()) {
                    Random random = new Random(Calendar.getInstance().getTimeInMillis());
                    JFrame_CSD200_FpCaptureAccess.this.currentSessionId = random.nextInt();
                    JFrame_CSD200_FpCaptureAccess.this.fingerprintCaptureApi.startCapture((IFingerprintCaptureCallbackAPI)new CaptureCallbackImpl(), JFrame_CSD200_FpCaptureAccess.this.currentSessionId, 30);
                }
            }
        });
        this.btnCapture.setFont(new Font("Tahoma", 0, 11));
        this.contentPane.add(this.btnCapture);
        this.btnAbort = new JButton("Abort");
        this.btnAbort.setBounds(251, 349, 105, 23);
        this.btnAbort.addActionListener(new ActionListener(){

            public void actionPerformed(ActionEvent e) {
                int ret = JFrame_CSD200_FpCaptureAccess.this.fingerprintCaptureApi.cancelCapture();
                if (ret < 0) {
                    System.out.println("Abort Failed. Error Code: " + ret);
                } else {
                    System.out.println("Capture Aborted.");
                    JFrame_CSD200_FpCaptureAccess.this.setDisplayedImageByteArray(null);
                    JFrame_CSD200_FpCaptureAccess.this.repaint();
                }
            }
        });
        this.btnAbort.setFont(new Font("Tahoma", 0, 11));
        this.contentPane.add(this.btnAbort);
        this.btnForceCapture = new JButton("Force Capture");
        this.btnForceCapture.setBounds(139, 349, 105, 23);
        this.btnForceCapture.addActionListener(new ActionListener(){

            public void actionPerformed(ActionEvent arg0) {
                JFrame_CSD200_FpCaptureAccess.this.setDisplayedImageByteArray(null);
                JFrame_CSD200_FpCaptureAccess.this.repaint();
                JFrame_CSD200_FpCaptureAccess.this.fingerprintCaptureApi.forceCapture();
            }
        });
        this.btnForceCapture.setFont(new Font("Tahoma", 0, 11));
        this.contentPane.add(this.btnForceCapture);
        this.btnDeviceInfo = new JButton("Device Info");
        this.btnDeviceInfo.setBounds(139, 383, 105, 23);
        this.btnDeviceInfo.addActionListener(new ActionListener(){

            public void actionPerformed(ActionEvent e) {
                if (JFrame_CSD200_FpCaptureAccess.this.fingerprintCaptureApi.isDeviceInitialized()) {
                    DeviceInfo devInfo = JFrame_CSD200_FpCaptureAccess.this.fingerprintCaptureApi.getDeviceInfo();
                    if (devInfo == null) {
                        JOptionPane.showMessageDialog(null, "Unable to fetch data.Please try again.");
                    } else {
                        JOptionPane.showMessageDialog(null, "Version: " + devInfo.getFirmwareVersion() + "\nModel: " + devInfo.getModel() + "\nSerial No: " + devInfo.getSerialNumber());
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Device Information Not Found.Please Initialize Device.");
                }
            }
        });
        this.btnDeviceInfo.setFont(new Font("Tahoma", 0, 11));
        this.contentPane.add(this.btnDeviceInfo);
        this.btnDeinit = new JButton("DeInit");
        this.btnDeinit.setBounds(251, 315, 105, 23);
        this.btnDeinit.addActionListener(new ActionListener(){

            public void actionPerformed(ActionEvent e) {
                int ret = JFrame_CSD200_FpCaptureAccess.this.fingerprintCaptureApi.deinitDevice();
                if (ret < 0) {
                    System.out.println("De-init Failed. Error Code: " + ret);
                } else {
                    System.out.println("De-Initialized.");
                    JFrame_CSD200_FpCaptureAccess.this.resetAll();
                    JFrame_CSD200_FpCaptureAccess.this.repaint();
                }
            }
        });
        this.btnDeinit.setFont(new Font("Tahoma", 0, 11));
        this.contentPane.add(this.btnDeinit);
        this.btnSaveBmpImage = new JButton("Save BMP Image");
        this.btnSaveBmpImage.setBounds(207, 185, 124, 23);
        this.btnSaveBmpImage.addActionListener(new ActionListener(){

            public void actionPerformed(ActionEvent e) {
                if (JFrame_CSD200_FpCaptureAccess.this.getDisplayedImageByteArray() != null) {
                    JFileChooser jfc = new JFileChooser("./");
                    FileNameExtensionFilter filter = new FileNameExtensionFilter("Bitmap Images", "bmp");
                    jfc.setFileFilter(filter);
                    int retVal = jfc.showSaveDialog(JFrame_CSD200_FpCaptureAccess.this.btnSaveBmpImage);
                    if (retVal == 0) {
                        try {
                            FileOutputStream fos2 = null;
                            try {
                                fos2 = new FileOutputStream(jfc.getSelectedFile());
                                byte[] byteArray = JFrame_CSD200_FpCaptureAccess.this.getDisplayedImageByteArray();
                                if (byteArray != null) {
                                    fos2.write(JFrame_CSD200_FpCaptureAccess.this.getDisplayedImageByteArray());
                                }
                            }
                            catch (FileNotFoundException byteArray) {
                                // empty catch block
                            }
                            fos2.close();
                        }
                        catch (IOException fos2) {
                        }
                        catch (NullPointerException fos2) {}
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "No images to save");
                }
            }
        });
        this.btnSaveBmpImage.setFont(new Font("Tahoma", 0, 11));
        this.contentPane.add(this.btnSaveBmpImage);
        this.btnSaveRawImage = new JButton("Save Raw Image");
        this.btnSaveRawImage.setBounds(207, 219, 124, 23);
        this.btnSaveRawImage.addActionListener(new ActionListener(){

            public void actionPerformed(ActionEvent e) {
                if (JFrame_CSD200_FpCaptureAccess.this.getDisplayedImageByteArray() != null) {
                    JFileChooser jfc = new JFileChooser("./");
                    FileNameExtensionFilter filter = new FileNameExtensionFilter("Raw Images", "raw");
                    jfc.setFileFilter(filter);
                    int retVal = jfc.showSaveDialog(JFrame_CSD200_FpCaptureAccess.this.btnSaveRawImage);
                    if (retVal == 0) {
                        try {
                            FileOutputStream fos2 = null;
                            try {
                                fos2 = new FileOutputStream(jfc.getSelectedFile());
                                byte[] rawBytes = JFrame_CSD200_FpCaptureAccess.this.bmpToRaw(JFrame_CSD200_FpCaptureAccess.this.getDisplayedImageByteArray());
                                if (rawBytes != null) {
                                    fos2.write(rawBytes);
                                }
                            }
                            catch (FileNotFoundException rawBytes) {
                                // empty catch block
                            }
                            fos2.close();
                        }
                        catch (IOException fos2) {
                        }
                        catch (NullPointerException fos2) {}
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "No images to save");
                }
            }
        });
        this.btnSaveRawImage.setFont(new Font("Tahoma", 0, 11));
        this.contentPane.add(this.btnSaveRawImage);
        this.lblFpImg1 = new JLabel("");
        this.lblFpImg1.setBounds(477, 120, 100, 150);
        this.lblFpImg1.setBorder(new LineBorder(Color.black));
        this.contentPane.add(this.lblFpImg1);
        this.lblFpImg2 = new JLabel("");
        this.lblFpImg2.setBounds(597, 120, 100, 150);
        this.lblFpImg2.setBorder(new LineBorder(Color.black));
        this.contentPane.add(this.lblFpImg2);
        this.btnMatchFingerprints = new JButton("Match Fingerprints");
        this.btnMatchFingerprints.setBounds(533, 310, 133, 23);
        this.btnMatchFingerprints.addActionListener(new ActionListener(){

            public void actionPerformed(ActionEvent arg0) {
                if (JFrame_CSD200_FpCaptureAccess.this.fp1FMRBytes != null && JFrame_CSD200_FpCaptureAccess.this.fp2FMRBytes != null) {
                    boolean bMatch = JFrame_CSD200_FpCaptureAccess.this.fingerprintCaptureApi.matchIso19794_2Templates(JFrame_CSD200_FpCaptureAccess.this.fp1FMRBytes, JFrame_CSD200_FpCaptureAccess.this.fp2FMRBytes);
                    if (bMatch) {
                        JOptionPane.showMessageDialog(JFrame_CSD200_FpCaptureAccess.this.btnMatchFingerprints, "Matched.", "", 0);
                    } else {
                        JOptionPane.showMessageDialog(JFrame_CSD200_FpCaptureAccess.this.btnMatchFingerprints, "Not Matched.", "", 1);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Unable to match two fingers.");
                }
            }
        });
        this.btnMatchFingerprints.setFont(new Font("Tahoma", 0, 11));
        this.contentPane.add(this.btnMatchFingerprints);
        ButtonGroup radioBtnGrp = new ButtonGroup();
        this.rbFp1 = new JRadioButton("FingerPrint - 1");
        this.rbFp1.setBounds(477, 275, 100, 23);
        this.rbFp1.setSelected(true);
        this.rbFp1.setFont(new Font("Tahoma", 0, 11));
        this.rbFp1.setBackground(Color.WHITE);
        radioBtnGrp.add(this.rbFp1);
        this.contentPane.add(this.rbFp1);
        this.rbFp2 = new JRadioButton("FingerPrint - 2");
        this.rbFp2.setBounds(597, 275, 100, 23);
        this.rbFp2.setFont(new Font("Tahoma", 0, 11));
        this.rbFp2.setBackground(Color.WHITE);
        radioBtnGrp.add(this.rbFp2);
        this.contentPane.add(this.rbFp2);
        this.lblLogo = new JLabel(new ImageIcon(JFrame_CSD200_FpCaptureAccess.class.getResource("/img/3M_Logo.gif")));
        this.lblLogo.setBounds(10, 10, 95, 64);
        this.contentPane.add(this.lblLogo);
        this.lblmCogentCsd = new JLabel("3M Cogent CSD200 FpCaptureAccess");
        this.lblmCogentCsd.setBounds(207, 33, 401, 29);
        this.lblmCogentCsd.setHorizontalAlignment(0);
        this.lblmCogentCsd.setForeground(Color.BLACK);
        this.lblmCogentCsd.setFont(new Font("Tahoma", 1, 14));
        this.contentPane.add(this.lblmCogentCsd);
        JButton btnCalibrate = new JButton("Calibrate");
        btnCalibrate.setBounds(139, 315, 105, 23);
        btnCalibrate.addActionListener(new ActionListener(){

            public void actionPerformed(ActionEvent e) {
                if (JFrame_CSD200_FpCaptureAccess.this.fingerprintCaptureApi.isDeviceInitialized()) {
                    Thread calibrateThread = new Thread(new calibrateWorker());
                    calibrateThread.setDaemon(true);
                    calibrateThread.start();
                } else {
                    JOptionPane.showMessageDialog(null, "Please Initialize Device");
                }
            }
        });
        btnCalibrate.setFont(new Font("Tahoma", 0, 11));
        this.contentPane.add(btnCalibrate);
        this.textArea = new JTextArea();
        this.textArea.setBounds(366, 237, 80, 160);
        this.textArea.setEditable(false);
        this.textArea.setBorder(new LineBorder(Color.black));
        JScrollPane scrollPane = new JScrollPane(this.textArea);
        scrollPane.setBounds(10, 417, 720, 172);
        scrollPane.setHorizontalScrollBarPolicy(32);
        scrollPane.setVerticalScrollBarPolicy(22);
        this.contentPane.add(scrollPane);
        this.lblNfiq1 = new JLabel("");
        this.lblNfiq1.setHorizontalAlignment(0);
        this.lblNfiq1.setFont(new Font("Tahoma", 1, 11));
        this.lblNfiq1.setBounds(477, 95, 100, 14);
        this.contentPane.add(this.lblNfiq1);
        this.lblNfiq2 = new JLabel("");
        this.lblNfiq2.setHorizontalAlignment(0);
        this.lblNfiq2.setFont(new Font("Tahoma", 1, 11));
        this.lblNfiq2.setBounds(597, 95, 100, 14);
        this.contentPane.add(this.lblNfiq2);
        this.setLocationRelativeTo(null);
    }

    public void resetAll() {
        this.setDisplayedImageByteArray(null);
        this.rbFp1.setSelected(true);
        this.fp1BMPBytes = null;
        this.fp2BMPBytes = null;
        this.fp1FMRBytes = null;
        this.fp2FMRBytes = null;
        this.lblNfiq1.setText("");
        this.lblNfiq2.setText("");
    }

    public void paint(Graphics g) {
        ImageIcon imgFp1;
        ImageIcon imgFp2;
        super.paint(g);
        Image fpImage = this.getFpImageToDisplay();
        if (fpImage != null) {
            ImageIcon imageIconFp = new ImageIcon(fpImage.getScaledInstance(-1, 170, 1));
            this.lblCaptureImg.setIcon(imageIconFp);
        }
        if (this.fp1BMPBytes != null) {
            BufferedImage capturedFp1Image = null;
            try {
                capturedFp1Image = ImageIO.read(new ByteArrayInputStream(this.fp1BMPBytes));
            }
            catch (IOException var4_4) {
                // empty catch block
            }
            imgFp1 = new ImageIcon(capturedFp1Image.getScaledInstance(-1, 140, 1));
            this.lblFpImg1.setIcon(imgFp1);
        } else if (this.fp1BMPBytes == null) {
            Image fp1Img = new ImageIcon(JFrame_CSD200_FpCaptureAccess.class.getResource("/img/Blank.JPG")).getImage();
            imgFp1 = new ImageIcon(fp1Img.getScaledInstance(-1, 140, 1));
            this.lblFpImg1.setIcon(imgFp1);
        }
        if (this.fp2BMPBytes != null) {
            BufferedImage capturedFp2Image = null;
            try {
                capturedFp2Image = ImageIO.read(new ByteArrayInputStream(this.fp2BMPBytes));
            }
            catch (IOException e) {
                // empty catch block
            }
            imgFp2 = new ImageIcon(capturedFp2Image.getScaledInstance(-1, 140, 1));
            this.lblFpImg2.setIcon(imgFp2);
        } else if (this.fp2BMPBytes == null) {
            Image fp2Img = new ImageIcon(JFrame_CSD200_FpCaptureAccess.class.getResource("/img/Blank.JPG")).getImage();
            imgFp2 = new ImageIcon(fp2Img.getScaledInstance(-1, 140, 1));
            this.lblFpImg2.setIcon(imgFp2);
        }
    }

    byte[] bmpToRaw(byte[] bmpBytes) {
        byte[] rawBytes = null;
        if (bmpBytes != null) {
            try {
                BufferedImage bufferedImage = ImageIO.read(new ByteArrayInputStream(bmpBytes));
                WritableRaster raster = bufferedImage.getRaster();
                DataBufferByte buffer = (DataBufferByte)raster.getDataBuffer();
                rawBytes = buffer.getData();
            }
            catch (IOException e) {
                e.printStackTrace();
            }
        }
        return rawBytes;
    }

    static /* synthetic */ void access$5(JFrame_CSD200_FpCaptureAccess jFrame_CSD200_FpCaptureAccess, JDialog jDialog) {
        jFrame_CSD200_FpCaptureAccess.dialog = jDialog;
    }

    class CaptureCallbackImpl
    implements IFingerprintCaptureCallbackAPI {
        CaptureCallbackImpl() {
        }

        public void onFingerprintCaptureCompleted(int sessionId, CapturedImageData capturedImageData) {
            byte[] capturedBytes = capturedImageData.getBmpImageData();
            JFrame_CSD200_FpCaptureAccess.this.setDisplayedImageByteArray(capturedBytes);
            Toolkit.getDefaultToolkit().beep();
            JFrame_CSD200_FpCaptureAccess.this.repaint();
            if (capturedBytes == null && -2222 == capturedImageData.getErrorCode()) {
                System.out.println("Error: Capture Timeout.");
            } else if (capturedBytes == null && -615 == capturedImageData.getErrorCode()) {
                System.out.println("Error: Previous Capture is in progress.");
            }
            if (JFrame_CSD200_FpCaptureAccess.this.rbFp1.isSelected() && capturedBytes != null) {
                JFrame_CSD200_FpCaptureAccess.this.fp1BMPBytes = capturedBytes;
                JFrame_CSD200_FpCaptureAccess.this.fp1FMRBytes = capturedImageData.getIso19794_2Template();
                JFrame_CSD200_FpCaptureAccess.this.lblNfiq1.setText("NFIQ : " + capturedImageData.getNfiq());
                if (JFrame_CSD200_FpCaptureAccess.this.fp1FMRBytes != null) {
                    System.out.println("Fp1 FMR Size: " + JFrame_CSD200_FpCaptureAccess.this.fp1FMRBytes.length);
                    System.out.println("Fp1 Minutiae Count: " + this.getMinutiaeCount(JFrame_CSD200_FpCaptureAccess.this.fp1FMRBytes));
                }
                System.out.println("NFIQ : " + capturedImageData.getNfiq());
            } else if (JFrame_CSD200_FpCaptureAccess.this.rbFp2.isSelected() && capturedBytes != null) {
                JFrame_CSD200_FpCaptureAccess.this.fp2BMPBytes = capturedBytes;
                JFrame_CSD200_FpCaptureAccess.this.fp2FMRBytes = capturedImageData.getIso19794_2Template();
                JFrame_CSD200_FpCaptureAccess.this.lblNfiq2.setText("NFIQ : " + capturedImageData.getNfiq());
                if (JFrame_CSD200_FpCaptureAccess.this.fp2FMRBytes != null) {
                    System.out.println("Fp2 FMR Size: " + JFrame_CSD200_FpCaptureAccess.this.fp2FMRBytes.length);
                    System.out.println("Fp2 Minutiae Count: " + this.getMinutiaeCount(JFrame_CSD200_FpCaptureAccess.this.fp2FMRBytes));
                }
                System.out.println("NFIQ : " + capturedImageData.getNfiq());
            }
            JFrame_CSD200_FpCaptureAccess.this.repaint();
        }

        public void onPreviewImageAvailable(int sessionId, byte[] bmpBytes, int width, int height) {
            if (bmpBytes != null) {
                JFrame_CSD200_FpCaptureAccess.this.setDisplayedImageByteArray(bmpBytes);
            }
            JFrame_CSD200_FpCaptureAccess.this.repaint();
        }

        private int getMinutiaeCount(byte[] fmrBytes) {
            int mntCount = -1;
            if (fmrBytes != null && fmrBytes.length > 27) {
                mntCount = fmrBytes[27];
            }
            return mntCount;
        }
    }

    final class calibrateWorker
    implements Runnable {
        public void run() {
            JOptionPane.showMessageDialog(null, "CSD200 Calibration is about to start.\nPlease keep the scanner clean and do not place finger on the scanner.");
            Thread dialogThread = new Thread(new dialogWorker(""));
            dialogThread.setDaemon(true);
            dialogThread.start();
            System.out.println("Calibration is in progress.");
            int calibrationRet = JFrame_CSD200_FpCaptureAccess.this.fingerprintCaptureApi.calibrateScanner();
            if (calibrationRet < 0) {
                System.out.println("Calibration Failed. Error Code: " + calibrationRet);
            } else {
                System.out.println("Calibration Success.");
            }
            if (dialogThread != null && JFrame_CSD200_FpCaptureAccess.this.dialog != null) {
                JFrame_CSD200_FpCaptureAccess.this.dialog.dispose();
                JFrame_CSD200_FpCaptureAccess.access$5(JFrame_CSD200_FpCaptureAccess.this, null);
            }
        }
    }

    final class dialogWorker
    implements Runnable {
        String displayStr;

        public dialogWorker(String inputString) {
            this.displayStr = null;
            this.displayStr = "Calibrating the fingerprint scanner.....\nPlease do not place finger on scanner";
            if (!inputString.isEmpty()) {
                this.displayStr = inputString;
            }
        }

        public void run() {
            JOptionPane optionPane = new JOptionPane(this.displayStr, 1, -1, null, new Object[0], null);
            JFrame_CSD200_FpCaptureAccess.access$5(JFrame_CSD200_FpCaptureAccess.this, new JDialog());
            JFrame_CSD200_FpCaptureAccess.this.dialog.setTitle("Message");
            JFrame_CSD200_FpCaptureAccess.this.dialog.setModal(true);
            JFrame_CSD200_FpCaptureAccess.this.dialog.setContentPane(optionPane);
            JFrame_CSD200_FpCaptureAccess.this.dialog.setDefaultCloseOperation(0);
            JFrame_CSD200_FpCaptureAccess.this.dialog.pack();
            JFrame_CSD200_FpCaptureAccess.this.dialog.setLocationRelativeTo(null);
            JFrame_CSD200_FpCaptureAccess.this.dialog.setVisible(true);
        }
    }

    final class initWorker
    implements Runnable {
        public void run() {
            if (!JFrame_CSD200_FpCaptureAccess.this.fingerprintCaptureApi.isDeviceInitialized()) {
                System.out.println("Initializing CSD200");
                int initRet = JFrame_CSD200_FpCaptureAccess.this.fingerprintCaptureApi.initDevice();
                if (initRet < 0) {
                    System.out.println("Initialization Failed. Error Code: " + initRet);
                } else {
                    System.out.println("Initialization success");
                }
            } else {
                System.out.println("Device is already Initialized.");
            }
            JFrame_CSD200_FpCaptureAccess.this.repaint();
        }
    }

}

